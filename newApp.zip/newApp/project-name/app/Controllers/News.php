<?php

namespace App\Controllers;

use App\Models\NewsModel;

class News extends BaseController
{
    public function index()
    {
        $model = new NewsModel;


        $data = [
            'news'  => $model->getNews(),
            'title' => 'News archive',
        ];
       
       // return (string) $data['news'][0]['title'];

        return view('templates/header', $data)
            . view('news/Titles', $data)
            . view('templates/footer');
    }

//Show method

    public function show($slug = null)
    {
        //return "We're in index" . $slug;

        $model =new NewsModel;

        $data['news'] = $model->getNews($slug);

        if (empty($data['news'])) {
            throw new PageNotFoundException('Cannot find the news item: ' . $slug);
        }

        $data['title'] = $data['news']['title'];

        return (string) $data['news'][0];

        return view('templates/header', $data)
            . view('news/view', $data)
            . view('templates/footer');
    }
}