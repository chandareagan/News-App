<?php

use App\Controllers\Home;
use App\Controllers\Pages;
use CodeIgniter\Router\RouteCollection;
use App\Controllers\News;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

//other news based routers
$routes->get('news', 'News::index');           
$routes->get('news/(:segment)', 'News::show/$1'); 

// Custom Routes
$routes->get('pages', [Pages::class, 'index']);
$routes->get('(:segment)', [Pages::class, 'view']);
