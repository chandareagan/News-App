<!Doctype html>
<html>
<head>
    <title> Simple App </head>
</head>

<body>
    <h1> <?= esc($title) ?> </h1>
