<?php

echo "Hello world";