<?php

echo "Hello world, home"; 